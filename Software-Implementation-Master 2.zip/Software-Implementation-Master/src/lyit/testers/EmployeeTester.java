/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lyit.testers;

import java.util.Scanner;
import lyit.bank.Date;
import lyit.bank.Employee;
import lyit.bank.Name;

/**
 *
 * @author Hp
 */
public class EmployeeTester {
    
    Scanner keyboard= new Scanner(System.in);
    Employee employee1, employee2;
    
    public static void main(String[] args) {
        EmployeeTester employeeTester = new EmployeeTester();
        employeeTester.setUpEmployees();
        employeeTester.Menu();
        
    }
    
    private void setUpEmployees(){
        System.out.println("Employee Tester");
        // display employee details on screen
        employee1= new Employee(new Name("Mr","Jon","son"), new Date(12,06,1993), new Date(01,10,2017), 2000.50);
        employee1.setNumber(++Employee.nextNumber);
        System.out.println(employee1);
        
    }
    private void Menu(){
        
        
        System.out.println("What do you want to do?");
        System.out.println("i: increment salary");
        System.out.println("w: calculate wage");
        System.out.print("Enter option: ");
        String option;
        option = keyboard.next();

        option = option.toLowerCase();
        switch(option){
            case "i":
                System.out.print("Enter incremented salary amount: ");
                String numbers = keyboard.next();
                while(!(numbers.matches("^[1-9]\\d*(\\.\\d+)?$"))){
                    System.out.print("enter a double number: ");
                    numbers = keyboard.next();
                }
                try{
                    double incrementedSalary = Double.parseDouble(numbers);
                    employee1.incrementSalary(incrementedSalary);
                }catch(IllegalArgumentException iAE){
                    System.out.print(iAE.getMessage());
                }
            break;
            
            case "w":
                System.out.print("Enter wage percentage As 5.67: ");
                String wage = keyboard.next();
                while(!(wage.matches("^[1-9]\\d*(\\.\\d+)?$"))){
                    System.out.print("enter a double number: ");
                    wage = keyboard.next();
                }
                double taxPercentage = Double.parseDouble(wage);
                System.out.println("Total wage amount is: " + employee1.calculateWage(taxPercentage));
            break;
            
            default:
                System.out.print("Wrong input, enter again: ");  
                            
        }
        Menu();
    }
    

}