package lyit.bank;

import java.text.DecimalFormat;

/**
 *
 * @author Hp
 */
public class Employee extends Person {

    private Date startDate;
    private double salary;
    private int number;
    public static int nextNumber = 0;    
    private final int MAXIMUMSALARY = 150000;
    
    // No parameter constructor 
    // Called when object is created like this
    //  ==> Employee emp= new Employee()
    public Employee() {

    }

    // Parameter constructor 
    // Called when object is created like this
    //  ==> Employee emp= new Employee(new Name("Mr John Son"), new Date(18,12,1990),new Date(12,6,2017), 2000.0 )
    public Employee(Name n, Date dob, Date startDate, double salary) {
        super(n, dob);
        this.startDate = startDate;
        this.salary = salary;
    }

    // set() and get() methods
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public static int getNextNumber() {
        return nextNumber;
    }

    public static void setNextNumber(int nextNumber) {
        Employee.nextNumber = nextNumber;
    }

    //toString() method to display employee object
    // ==> Display employee object as:
    // EMPLOYEE 12,06,2018, 2000, Mr Jon son, 12,12,1992
    @Override
    public String toString() {
        return "EMPLOYEE " +  startDate + ", " + salary + ","
                + super.toString();
    }

    // equals() method
    // ==> Called when comparing an object with another object, 
    //     e.g. - if(e1.equals(e2))	
    @Override
    public boolean equals(Object obj) {
        Employee eObject;
        if (obj instanceof Employee) {
            eObject = (Employee) obj;
        } else {
            return false;
        }
        return (startDate.equals(eObject.startDate)
                && salary == eObject.salary
                && number == eObject.number);
    }
 
    // This function use to increment the salary of an employee
    // it also throw exception if salary limit exceeds MAXIMUMSALARY
    public void incrementSalary(double salaryAmount)  throws IllegalArgumentException {
        double totalSalary = this.salary + salaryAmount;
        if(totalSalary<this.MAXIMUMSALARY){
            System.out.print("New salary after incement is: " + totalSalary +"\n");
        }else{
            // ERROR will occur ==> throw exception
            // Method will stop at this point if exception thrown
            throw new IllegalArgumentException("Salary amount exceeds its limit\n");
        }
        
    }
    
    //This method will calculate the wage of an employee
    // It requires taxpercentage as input and return wage in double
    public double calculateWage(double taxPercentage){
        DecimalFormat decimalFormat = new DecimalFormat("#.000");
        double wage=this.salary/12;
        wage -= wage * taxPercentage/100;
        
        return Double.parseDouble(decimalFormat.format(wage));
    }
}
