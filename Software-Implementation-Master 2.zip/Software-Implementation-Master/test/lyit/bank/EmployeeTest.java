/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lyit.bank;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Hp
 */
public class EmployeeTest {
    
    public EmployeeTest() {
    }
    
    Employee employee;
    @Before
    public void setUp() {
        employee= new Employee(new Name("Mr","William","Jones"), new Date(12,8,1990), new Date(01,5,2019), 80000.50);
        employee.setNumber(Employee.nextNumber++);
    }


    /**
     * Test of setStartDate method, of class Employee.
     */
    @Test
    public void testSetStartDate() {
        System.out.println("SetStartDate Test: ");
        Date startDate = new Date(01,5,2019);
        Employee instance = new Employee();
        instance.setStartDate(startDate);
        assertEquals(startDate, instance.getStartDate());
    }


    /**
     * Test of setSalary method, of class Employee.
     */
    @Test
    public void testSetSalary() {
        System.out.println("SetSalaryDate Test: ");
        double salary = 30000.34;
        Employee instance = new Employee();
        instance.setSalary(salary);
        assertEquals(salary, instance.getSalary(), 0.0);
    }

    /**
     * Test of setNumber method, of class Employee.
     */
    @Test
    public void testSetNumber() {
        System.out.println("SetNumber Test");
        int number = Employee.nextNumber++;
        Employee instance = new Employee();
        instance.setNumber(number);
        assertEquals(number, instance.getNumber());
         System.out.println("Number " + number);
    }


    /**
     * Test of setNextNumber method, of class Employee.
     */
    @Test
    public void testSetNextNumber() {
        System.out.println("SetNextNumber Test");
        int nextNumber = Employee.nextNumber++;
        Employee.setNextNumber(nextNumber);
        assertEquals(nextNumber, Employee.getNextNumber());
        System.out.println("Number " + nextNumber);
    }

    /**
     * Test of toString method, of class Employee.
     */
    @Test
    public void testToString() {
        System.out.println("toString Test: ");
        String expResult = "EMPLOYEE 1/5/2019, 80000.5,Mr William Jones,12/8/1990";
        String result = employee.toString();
        assertEquals(expResult, result);
    }

    /**
     * Test of equals method, of class Employee.
     */
    @Test
    public void testEquals() {
        System.out.println("equals Test: ");
        Object obj = null;
        Employee instance = new Employee(new Name("Mr","William","Jones"), new Date(12,8,1990), new Date(01,5,2019), 80000.50);
        instance.setNumber(Employee.nextNumber++);
        boolean expResult = false;      //Different numbers
        boolean result = instance.equals(employee);
        assertEquals(expResult, result);
        System.out.print(result);
    }

    /**
     * Test of incrementSalary method, of class Employee.
     */
    @Test
    public void testIncrementSalary() {
        System.out.println("IncrementSalary Test");
        double salaryAmount = 20000.0;
        try{
            employee.incrementSalary(salaryAmount);
            assertEquals(100000.50, 100000.50, 0.0);
        }catch(IllegalArgumentException iAE){
            System.out.print(iAE.getMessage());
        }
        
    }

    /**
     * Test of calculateWage method, of class Employee.
     */
    @Test
    public void testCalculateWage() {
        System.out.println("CalculateWage Test");
        double taxPercentage = 12.9;
        double expResult = 5806.703;
        double result = employee.calculateWage(taxPercentage);
        assertEquals(expResult, result, 0.0);
    }
    
}
